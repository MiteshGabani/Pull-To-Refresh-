package com.example.pulltorefresh

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    var textItems = ArrayList<String>()
    var number = 9

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //dataset for feed
        textItems.add("Feed Text 1")
        textItems.add("Feed Text 2")
        textItems.add("Feed Text 3")
        textItems.add("Feed Text 4")
        textItems.add("Feed Text 5")
        textItems.add("Feed Text 6")
        textItems.add("Feed Text 7")
        textItems.add("Feed Text 8")
        textItems.add("Feed Text 9")

        //setting up adapter for recyclerview
        mainFeed.layoutManager = LinearLayoutManager(this)
        val mainfeedadapter = mainFeedAdapter(this, textItems)
        mainFeed.adapter = mainfeedadapter

        //implementing onrefresh method for refreshing feed
        swipeRefreshArea.setOnRefreshListener {

            //adding new data for feed
            addNewDataToFeed()
            mainfeedadapter.notifyDataSetChanged()

            swipeRefreshArea.isRefreshing =false
        }
    }

    fun addNewDataToFeed(){
        //adding one new record for every refresh
        textItems.add("Feed Text "+ ++number)
    }
}