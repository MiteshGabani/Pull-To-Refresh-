package com.example.pulltorefresh

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class mainFeedAdapter(var context:Context,var feedData:ArrayList<String>):RecyclerView.Adapter<mainFeedAdapter.viewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
        return viewHolder( LayoutInflater.from(context).inflate(R.layout.main_feed_item,parent,false))
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        holder.mainFeedItem.text =feedData[position]
    }

    override fun getItemCount(): Int {
        return feedData.size
    }

    inner class viewHolder(itemView:View): RecyclerView.ViewHolder(itemView){
        var mainFeedItem =itemView.findViewById<TextView>(R.id.mainFeedItem)
    }
}